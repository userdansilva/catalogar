import { z } from "zod";

export const catalogItemImageSchema = z.object({
  id: z.uuidv4(),
  fileName: z.string(),
  url: z.string(),
  size: z.number(),
  width: z.number(),
  height: z.number(),
  altText: z.string().optional(),
  position: z.number(),
  createdAt: z.string(),
});

export type CatalogItemImage = z.infer<typeof catalogItemImageSchema>;

/* eslint-disable @next/next/no-html-link-for-pages */
"use client";

import { buttonVariants } from "@/components/ui/button";
import Image from "next/image";
import logo from "@/assets/images/logo.svg";

export default function SignInOrRegister() {
  return (
    <div className="bg-background flex min-h-screen flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="flex justify-center">
          <Image src={logo} alt="Logo escrito catalogar" width={246} />
        </div>

        <div className="text-center">
          <h1 className="text-2xl tracking-tight">
            Boas Vindas ao <span className="font-bold">Catalogar</span>
          </h1>
          <p className="text-muted-foreground mt-4">
            Entre para gerenciar seus catálogos ou criar um novo cadastro
          </p>
        </div>

        <div className="mt-8 flex justify-center">
          <a
            href="/auth/login"
            className={buttonVariants({
              size: "lg",
            })}
          >
            Entrar / Cadastrar
          </a>
        </div>

        <p className="text-muted-foreground mt-6 text-center text-sm" />
      </div>
    </div>
  );
}

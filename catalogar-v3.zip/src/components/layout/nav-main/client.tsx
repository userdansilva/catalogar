"use client";

import {
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Lock } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { CatalogItem, Prisma } from "@/generated/prisma/client";
import { routes } from "@/routes";

type NavMainClientProps = {
  currentCatalog: Prisma.CatalogGetPayload<{
    include: {
      company: true;
      theme: true;
      categories: true;
      productTypes: true;
    };
  }> & {
    catalogItems: (Omit<CatalogItem, "price"> & {
      price: string | null;
    })[];
  };
};

export function NavMainClient({ currentCatalog }: NavMainClientProps) {
  const { setOpenMobile } = useSidebar();
  const pathname = usePathname();

  const groups = [
    {
      name: "Menus",
      items: [
        {
          ...routes.dashboard,
          isLocked: false,
          lockReason: "",
          isActive: pathname === routes.dashboard.url,
        },
        {
          ...routes.productTypes,
          url:
            currentCatalog.productTypes.length === 0
              ? routes.productTypes.sub.createFirst.url
              : routes.productTypes.url,
          isLocked: false,
          lockReason: "",
          isActive: pathname.startsWith(routes.productTypes.url),
        },
        {
          ...routes.categories,
          url:
            currentCatalog.categories.length === 0
              ? routes.categories.sub.createFirst.url
              : routes.categories.url,
          isLocked: false,
          lockReason: "",
          isActive: pathname.startsWith(routes.categories.url),
        },
        {
          ...routes.catalogItems,
          url:
            currentCatalog.catalogItems.length === 0
              ? routes.catalogItems.sub.createFirst.url
              : routes.catalogItems.url,
          isLocked: currentCatalog.productTypes.length === 0,
          lockReason: "Adicione um tipo de produto para desbloquear o Catálogo",
          isActive: pathname.startsWith(routes.catalogItems.url),
        },
      ],
    },
    {
      name: "Utilidades",
      items: [
        {
          ...routes.preview,
          isLocked: currentCatalog.catalogItems.length === 0,
          lockReason: "Adicione um item no Catálogo para desbloquear o Preview",
          isActive: pathname.startsWith(routes.preview.url),
        },
      ],
    },
    {
      name: "Personalização",
      items: [
        {
          ...routes.company,
          url: currentCatalog.company
            ? routes.company.url
            : routes.company.sub.new.url,
          isLocked: false,
          lockReason: "",
          isActive: pathname.startsWith(routes.company.url),
        },
        {
          ...routes.theme,
          url: currentCatalog.theme
            ? routes.theme.url
            : routes.theme.sub.new.url,
          isLocked: false,
          lockReason: "",
          isActive: pathname.startsWith(routes.theme.url),
        },
        {
          ...routes.config,
          isLocked: false,
          lockReason: "",
          isActive: pathname.startsWith(routes.config.url),
        },
      ],
    },
  ];

  return groups.map((group) => (
    <SidebarGroup key={group.name}>
      <SidebarGroupLabel>{group.name}</SidebarGroupLabel>

      <SidebarGroupContent>
        <SidebarMenu>
          {group.items.map((item) => (
            <SidebarMenuItem key={item.title}>
              {item.isLocked ? (
                <Tooltip>
                  <TooltipTrigger
                    render={
                      <SidebarMenuButton tooltip={item.title}>
                        <item.icon />
                        <span>{item.title}</span>
                        <Lock className="ml-auto" />
                      </SidebarMenuButton>
                    }
                  />

                  <TooltipContent side="right" className="max-w-80">
                    {item.lockReason}
                  </TooltipContent>
                </Tooltip>
              ) : (
                <SidebarMenuButton
                  tooltip={item.title}
                  isActive={item.isActive}
                  render={
                    <Link href={item.url} onClick={() => setOpenMobile(false)}>
                      <item.icon />
                      <span>{item.title}</span>
                    </Link>
                  }
                />
              )}
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  ));
}

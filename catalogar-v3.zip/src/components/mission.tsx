import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Circle, CircleCheck, Lock } from "lucide-react";
import Link from "next/link";
import { routes } from "@/routes";

export function Mission({
  title,
  description,
  status = "PENDING",
  href,
  isOptional,
  callbackUrl,
}: {
  title: string;
  description: string;
  status: "COMPLETE" | "CURRENT" | "PENDING";
  href: string;
  isOptional?: boolean;
  callbackUrl?: string;
}) {
  const isComplete = status === "COMPLETE";
  const isCurrent = status === "CURRENT";
  const isPending = status === "PENDING";

  return (
    <div
      className={cn(
        "space-y-6 rounded-md border px-4 py-2",
        isComplete && "border-green-200 bg-green-50",
      )}
    >
      <div className="space-y-4">
        <div className="flex items-center gap-4">
          {isComplete && <CircleCheck className="size-5 text-green-500" />}
          {isCurrent && <Circle className="size-5" />}
          {isPending && <Lock className="text-muted-foreground size-5" />}

          <h3
            className={cn(
              "flex-1 text-sm font-medium",
              isPending && "text-muted-foreground",
            )}
          >
            {title}
          </h3>

          <Badge
            className={cn(
              isComplete && "bg-green-100 text-green-500 shadow-none",
            )}
            variant={isPending ? "outline" : "default"}
          >
            {isComplete && "Finalizada"}
            {isCurrent && "Atual"}
            {isPending && "Pendente"}
          </Badge>
        </div>

        {isCurrent && (
          <p className="text-muted-foreground text-sm">{description}</p>
        )}
      </div>

      {isCurrent && (
        <div className="flex items-center gap-2">
          <Link
            href={{
              pathname: href,
              query: {
                callbackUrl: callbackUrl || routes.dashboard.url,
              },
            }}
            prefetch
            className={buttonVariants()}
          >
            Vamos lá
          </Link>

          {isOptional && (
            <Link
              href={{
                query: {
                  pular: "categoria",
                },
              }}
              className={buttonVariants({
                variant: "outline",
              })}
            >
              Pular
            </Link>
          )}
        </div>
      )}
    </div>
  );
}

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Plus, X } from "lucide-react";
import NextImage from "next/image";
import { useAction } from "next-safe-action/hooks";
import { type ChangeEvent, useRef } from "react";
import { createImageAction } from "@/actions/create-image-action";
import { toast } from "../ui/toast";
import { Button } from "../ui/button";
import { Spinner } from "../ui/spinner";

type Image = {
  fileName: string;
  url: string;
  size: number;
  width: number;
  height: number;
  altText: string;
  position: number;
};

export function InputImages({
  onChange,
  value,
  disabled,
}: {
  value?: Image[];
  onChange: (x: Image[]) => void;
  disabled?: boolean;
}) {
  const buttonContainerRef = useRef<HTMLDivElement>(null);
  const inputFileRef = useRef<HTMLInputElement>(null);
  const { executeAsync, isExecuting } = useAction(createImageAction);

  const handleChange = async (e: ChangeEvent<HTMLInputElement>) => {
    try {
      const file = e.target.files?.[0];

      if (!file) throw new Error();

      if ((file.size || 0) > 5.1 * 1024 * 1024) {
        toast.add({
          type: "warning",
          title: "Imagem muito pesada",
          description: "Tamanho máximo é de 5MB",
        });

        return;
      }

      const formData = new FormData();
      formData.append("image", file);

      const { data, serverError } = await executeAsync(formData);

      if (serverError) {
        toast.add({
          type: "error",
          description: serverError.message,
        });

        return;
      }

      if (!data) throw new Error();

      onChange([
        ...(value ?? []),
        {
          fileName: data.fileName,
          url: data.url,
          size: data.size,
          width: data.width,
          height: data.height,
          altText: "",
          position: (value ?? []).length + 1,
        },
      ]);

      // scroll right
      if (buttonContainerRef.current) {
        setTimeout(() => {
          buttonContainerRef.current?.scrollIntoView({
            block: "center",
            behavior: "smooth",
          });
        }, 1_500);
      }
    } catch (error) {
      console.error(error);

      toast.add({
        type: "error",
        description:
          "Falha inesperada ao carregar imagem, por favor tente novamente",
      });
    } finally {
      // reset input
      if (inputFileRef.current) {
        inputFileRef.current.value = "";
      }
    }
  };

  const handleRemove = (url: string) => {
    onChange(
      (value ?? [])
        .filter((image) => image.url !== url)
        .map((image, i) => ({ ...image, position: i + 1 })),
    );
  };

  return (
    <>
      <ScrollArea className="border-input w-full max-w-[calc(100vw-40px)] rounded-md border bg-transparent text-base shadow-xs md:text-sm">
        <div className="flex w-max gap-x-4 p-3">
          {(value ?? []).map((image) => (
            <div className="relative size-52 rounded-md" key={image.url}>
              <AlertDialog>
                <AlertDialogTrigger
                  render={
                    <Button
                      size="icon-sm"
                      className="absolute top-1.5 right-1.5"
                      variant="destructive"
                    />
                  }
                >
                  <X />
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>
                      Tem certeza que quer remover a imagem?
                    </AlertDialogTitle>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={() => handleRemove(image.url)}>
                      Sim! Quero remover
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              <NextImage
                src={image.url}
                alt=""
                width={208}
                height={208}
                className="rounded-sm"
                unoptimized
              />
            </div>
          ))}

          <div ref={buttonContainerRef}>
            <Button
              disabled={isExecuting || disabled}
              type="button"
              variant="outline"
              className="mr-3 flex size-52 flex-col"
              onClick={() => {
                inputFileRef.current?.click();
              }}
            >
              {isExecuting ? (
                <>
                  <Spinner data-icon="inline-start" />
                  Adicionando...
                </>
              ) : (
                <>
                  <Plus />
                  Adicionar
                </>
              )}
            </Button>
          </div>
        </div>

        <ScrollBar orientation="horizontal" />
      </ScrollArea>

      <input
        type="file"
        accept="image/*"
        hidden
        ref={inputFileRef}
        onChange={handleChange}
        multiple={false}
      />
    </>
  );
}
